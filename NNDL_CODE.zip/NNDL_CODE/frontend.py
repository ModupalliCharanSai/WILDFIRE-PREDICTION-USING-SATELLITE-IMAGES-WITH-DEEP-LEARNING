import streamlit as st
from PIL import Image
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img

# Load the saved model
#model = tf.keras.models.load_model('trained_model.h5')
model = tf.keras.models.load_model('trained_model.h5')
# Define the class labels
class_labels = ['Wildfire','No wildfire']

# Set the page title
st.title('wild fire  Detection')


# Upload image
uploaded_image = st.file_uploader('Upload an image', type=['jpg', 'jpeg', 'png'])
submit_button = st.button('Submit')

# Check if an image is uploaded
if submit_button and uploaded_image is not None:
    # Open and display the image
    img = Image.open(uploaded_image)
    st.image(img, caption='Uploaded Image', use_column_width=True)
    
    # Resize the image to match the model's input shape
    img = img.resize((32, 32))
    
    # Convert the image to an array and normalize the pixel values
    img_array = img_to_array(img)
    img_array = img_array / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    
    # Make the prediction
    prediction = model.predict(img_array)
    predicted_class = np.argmax(prediction)
    
    # Show the predicted class
    st.subheader('Prediction')
    st.write('Predicted Class:', class_labels[predicted_class])
